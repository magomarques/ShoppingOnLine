from django.apps import AppConfig


class AppShoppingConfig(AppConfig):
    name = 'app_shopping'
