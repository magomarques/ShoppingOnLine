from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
import json
from django.views.decorators.csrf import csrf_exempt
from .models import Loja
from rest_framework.status import HTTP_200_OK
import os
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import sqlite3


# Create your views here.

def upload(request):
    if request.method == 'POST' and request.FILES['foto']:
        
        myfile = request.FILES['foto']
        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        
        return uploaded_file_url

def inicio(request):
    if request.method == 'GET':
        
        lojas = Loja.objects.all()

        contexto = {
            'lista_lojas': lojas
        }
    return render(request, 'inicio.html', contexto)

def form_cadastrar(request):
    return render(request, "form_cadastrar.html")

def cadastrar(request):

    response = {}

    if request.method == 'POST':

        loja = Loja()
        loja.nome = request.POST.get('nome')
        loja.cnpj = request.POST.get('cnpj')
        loja.contato = request.POST.get('contato')
        loja.telefone = request.POST.get('telefone')
        loja.rede_social = request.POST.get('rede_social')
        loja.foto = upload(request)

        loja.save()

        response = {
            'response': HTTP_200_OK
        }

    return HttpResponseRedirect('/app_shopping/inicio')

def listar(request):

    if request.method == 'GET':
        
        lojas = Loja.objects.all()

        contexto = {
            'lista_lojas': lojas
        }

    return render(request, "listar.html", contexto)

def form_editar(request, user_id):
    
    if request.method == 'GET':
        
        loja = Loja.objects.filter(id=user_id)

        contexto = {
            'dados_loja': loja
        }

    return render(request, "form_editar.html", contexto)

def editar(request):
    
    if request.method == 'POST':

        nome = request.POST.get('nome')
        cnpj = request.POST.get('cnpj')
        contato = request.POST.get('contato')
        telefone = request.POST.get('telefone')
        rede_social = request.POST.get('rede_social')
        foto = upload(request)
        user_id = request.POST.get('user_id')

        loja = Loja.objects.filter(id=user_id)
        loja.update(nome=nome, cnpj=cnpj, contato=contato, telefone=telefone, rede_social=rede_social, foto=foto)

        return HttpResponseRedirect('/app_shopping/inicio')

def excluir(request, user_id):

    if request.method == 'GET':
        loja = Loja.objects.filter(id=user_id)
        loja.delete()

    return HttpResponseRedirect('/app_shopping/inicio')

def loja(request, user_id):
    
    if request.method == 'GET':
        
        loja = Loja.objects.filter(id=user_id)

        contexto = {
            'dados_loja': loja
        }
    #return contexto
    return render(request, "loja.html", contexto)



