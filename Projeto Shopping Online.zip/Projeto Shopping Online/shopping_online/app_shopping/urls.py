from django.urls import path, include
from . import views
from django.conf.urls.static import static
from shopping_online import settings
from django.conf import settings
from django.conf import settings
from django.conf.urls.static import static


app_name = 'app_shopping'

urlpatterns = [
    path('inicio', views.inicio, name='inicio'),
    path('form_cadastrar', views.form_cadastrar, name='form_cadastrar'),
    path('cadastrar', views.cadastrar, name='cadastrar'),
    path('listar', views.listar, name='listar'),
    path('form_editar/<int:user_id>', views.form_editar, name='form_editar'),
    path('editar', views.editar, name='editar'),
    path('excluir/<int:user_id>', views.excluir, name='excluir'),
    path('loja/<int:user_id>', views.loja, name='loja')
]


# IMPORTANTE: Para poder importar imagens.
if settings.DEBUG:
    urlpatterns = urlpatterns + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
