from django.db import models

# Create your models here.

class Loja(models.Model):
    nome = models.CharField(
        max_length=255,
        null=False,
        blank=False,
        default=0
    )

    cnpj = models.CharField(
        max_length=15,
        null=False,
        blank=False,
        default=0
    )

    contato = models.CharField(
        max_length=255,
        null=False,
        blank=False,
        default=0
    )

    telefone = models.CharField(
        max_length=15,
        null=False,
        blank=False,
        default=0
    )

    rede_social = models.CharField(
        max_length=255,
        null=False,
        blank=False,
        default=0
    )

    foto = models.FileField(
        upload_to="media",
        default='SEM VITRINE'
    )

    #IMPORTANTE: Tem que instalar o Pillow (pip install Pillow)
    # foto = models.ImageField(
    #     upload_to='media'
    # )

    #objects = models.Manager()

